oauth2client.django_orm module
==============================

.. automodule:: oauth2client.django_orm
    :members:
    :undoc-members:
    :show-inheritance:
