oauth2client.devshell module
============================

.. automodule:: oauth2client.devshell
    :members:
    :undoc-members:
    :show-inheritance:
