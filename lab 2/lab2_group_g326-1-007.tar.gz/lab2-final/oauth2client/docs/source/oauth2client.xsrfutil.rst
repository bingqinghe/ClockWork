oauth2client.xsrfutil module
============================

.. automodule:: oauth2client.xsrfutil
    :members:
    :undoc-members:
    :show-inheritance:
