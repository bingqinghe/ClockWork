oauth2client.keyring_storage module
===================================

.. automodule:: oauth2client.keyring_storage
    :members:
    :undoc-members:
    :show-inheritance:
