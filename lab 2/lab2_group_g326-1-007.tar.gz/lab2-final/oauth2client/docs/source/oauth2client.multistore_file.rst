oauth2client.multistore_file module
===================================

.. automodule:: oauth2client.multistore_file
    :members:
    :undoc-members:
    :show-inheritance:
